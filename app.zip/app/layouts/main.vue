<template>
  <div id="layout-container" class="font-jost bg-veryLightBlue flex flex-col items-center h-screen">
    <slot />
  </div>
</template>
  